# AlexLogLibPy
Small logging package
