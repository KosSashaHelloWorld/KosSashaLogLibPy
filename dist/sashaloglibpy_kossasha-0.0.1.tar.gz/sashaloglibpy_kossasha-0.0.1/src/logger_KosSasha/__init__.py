'''Small logger module'''
from logger_KosSasha import logger