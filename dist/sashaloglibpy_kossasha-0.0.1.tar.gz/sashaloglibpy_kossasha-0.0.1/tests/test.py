# from logger_KosSasha import Logger
from logger import Logger

def testLogger():
    logger = Logger(Logger.DEBUG, 4)

    logger.dbg("dbg msg")
    logger.inf("inf msg")
    logger.wrn("wrn msg")
    logger.err("err msg")

    print(logger._Logger__stackTraceLines)

testLogger()
